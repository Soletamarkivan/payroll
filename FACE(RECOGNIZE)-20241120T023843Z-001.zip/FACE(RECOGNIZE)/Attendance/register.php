<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$employee_db = "employeemanagement"; // Database for employee data

// Create connection for employee database
$employee_conn = new mysqli($servername, $username, $password, $employee_db);

if ($employee_conn->connect_error) {
    die("Employee Database Connection failed: " . $employee_conn->connect_error);
}

// Handle employee registration (POST request)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $firstName = $_POST['firstName'];
    $middleName = $_POST['middleName'];
    $lastName = $_POST['lastName'];
    $age = $_POST['age'];
    $status = $_POST['status'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $salary = $_POST['salary'];
    $department = $_POST['department'];
    $position = $_POST['position'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password
    $role = $_POST['role'];
    $photo = $_POST['photo'];

    // Convert photo (Base64) to binary
    $photoData = base64_decode(str_replace('data:image/png;base64,', '', $photo));

    // Insert employee data into the employees table
    $sql = "INSERT INTO employees (first_name, middle_name, last_name, age, status, email, phone, salary, department, position)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $employee_conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $employee_conn->error);
    }

    $stmt->bind_param(
        "ssssssssss",
        $firstName, $middleName, $lastName, $age, $status, $email, $phone, $salary,
        $department, $position
    );

    if ($stmt->execute()) {
        $employee_id = $stmt->insert_id; // Get the last inserted employee ID

        // Now insert the user data into the useremployee table
        $sql_user = "INSERT INTO useremployee (username, password, role, photo, employee_id)
                     VALUES (?, ?, ?, ?, ?)";
        $stmt_user = $employee_conn->prepare($sql_user);

        if (!$stmt_user) {
            die("Prepare failed: " . $employee_conn->error);
        }

        $stmt_user->bind_param(
            "ssssi",
            $username, $password, $role, $photoData, $employee_id
        );

        if ($stmt_user->execute()) {
            echo "Employee registration successful!";
        } else {
            echo "Error inserting user data: " . $stmt_user->error;
        }

        // Close the user statement
        $stmt_user->close();
    } else {
        echo "Error inserting employee data: " . $stmt->error;
    }

    // Close the employee statement
    $stmt->close();
}

// Close the database connection
$employee_conn->close();
?>