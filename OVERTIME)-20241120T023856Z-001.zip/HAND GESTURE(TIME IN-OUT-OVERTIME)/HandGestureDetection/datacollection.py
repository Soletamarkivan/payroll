import cv2
import mediapipe as mp
import time
import datetime
import mysql.connector

# Initialize Mediapipe hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)

# Initialize video capture
cap = cv2.VideoCapture(0)

# Fixed employee ID and name
employee_id = 1
employee_name = "Cristine Marcos"

# Connect to MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="root",  # Replace with your MySQL username
    password="",  # Replace with your MySQL password
    database="attendancedb"
)
cursor = db.cursor()

def detect_gesture(landmarks):
    if landmarks is None:
        return None

    # Extract the landmarks of the hand
    thumb_tip = landmarks[mp_hands.HandLandmark.THUMB_TIP]
    index_tip = landmarks[mp_hands.HandLandmark.INDEX_FINGER_TIP]
    ring_tip = landmarks[mp_hands.HandLandmark.RING_FINGER_TIP]

    # Time In gesture - single index finger
    if index_tip.y < thumb_tip.y and ring_tip.y > index_tip.y:
        return 'time_in'

    # Time Out gesture - single ring finger
    elif ring_tip.y < thumb_tip.y and index_tip.y > ring_tip.y:
        return 'time_out'

    # Overtime gesture - "trap thumb" position
    elif thumb_tip.y < index_tip.y and thumb_tip.x > index_tip.x:
        return 'overtime'

    return None

def mark_attendance(emp_id, emp_name, action):
    current_time = datetime.datetime.now()
    date = current_time.date()
    time_now = current_time.time()

    # Check if attendance for the day exists
    cursor.execute("SELECT * FROM attendancerecord WHERE employeename = %s AND date = %s", (emp_name, date))
    record = cursor.fetchone()

    if action == 'time_in':
        if record is None:
            # Insert new record with time_in
            cursor.execute("INSERT INTO attendancerecord (employeename, date, time_in) VALUES (%s, %s, %s)",
                           (emp_name, date, time_now))
            db.commit()
            print(f'Employee {emp_name} logged in at {time_now}.')
        else:
            print(f'Attendance already marked for Employee {emp_name}.')

    elif action == 'time_out':
        if record and record[4] is None:  # record[4] is time_out
            # Update the record with time_out
            cursor.execute("UPDATE attendancerecord SET time_out = %s WHERE id = %s", (time_now, record[0]))
            db.commit()
            print(f'Employee {emp_name} logged out at {time_now}.')
        else:
            print(f'No time-in record found or time-out already marked for Employee {emp_name}.')

    elif action == 'overtime':
        if record and record[5] is None:  # record[5] is overtime
            # Update the record with overtime
            cursor.execute("UPDATE attendancerecord SET overtime = %s WHERE id = %s", (time_now, record[0]))
            db.commit()
            print(f'Employee {emp_name} started overtime at {time_now}.')
        else:
            print(f'Overtime already marked for Employee {emp_name}.')

# Main loop
while True:
    success, image = cap.read()
    if not success:
        break

    image = cv2.flip(image, 1)  # Flip the image for a mirror effect
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = hands.process(image_rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            gesture = detect_gesture(hand_landmarks.landmark)

            if gesture == 'time_in':
                mark_attendance(employee_id, employee_name, 'time_in')
                time.sleep(2)  # Prevent multiple detections

            elif gesture == 'time_out':
                mark_attendance(employee_id, employee_name, 'time_out')
                time.sleep(2)  # Prevent multiple detections

            elif gesture == 'overtime':
                mark_attendance(employee_id, employee_name, 'overtime')
                time.sleep(2)  # Prevent multiple detections

            # Draw hand landmarks on the image
            mp.solutions.drawing_utils.draw_landmarks(image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

    cv2.imshow("Attendance System", image)

    # Exit on 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release resources
cap.release()
cv2.destroyAllWindows()
cursor.close()
db.close()
